<?php 

class Sendbox_Shipping_API{ 
  //make a post to sendbox api using curl.
  public function post_on_api_by_curl($url, $data, $api_key)
	{
		$ch = curl_init($url);
		// Setup request to send json via POST.
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'Authorization:' . $api_key));
		// Return response instead of printing.
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Send request.
		$result = curl_exec($ch);
		curl_close($ch);
		// Print response.
		return $result;
  } 
  
  //make a get request using curl to sendbox 

  public function get_api_response_by_curl($url)
	{
		$handle = curl_init();
		curl_setopt($handle, CURLOPT_URL, $url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		$output = curl_exec($handle);
		curl_close($handle);
		return $output;
  }

  
  //all sendbox endpoints
  public function get_sendbox_api_url($url_type)
	{
		if ('delivery_quote' == $url_type) {
			$url = 'https://api.sendbox.ng/v1/merchant/shipments/delivery_quote';
		} elseif ('countries' == $url_type) {
			$url = 'https://api.sendbox.co/auth/countries?page_by={' . '"per_page"' . ':264}';
		} elseif ('states' == $url_type) {
			$url = 'https://api.sendbox.co/auth/states';
		} elseif ('shipments' == $url_type) {
			$url = 'https://api.sendbox.ng/v1/merchant/shipments';
		} elseif ('item_type' == $url_type) {
			$url = 'https://api.sendbox.ng/v1/item_types';
		} elseif ('profile' == $url_type) {
			$url = 'https://api.sendbox.ng/v1/merchant/profile';
		} else {
			$url = '';
		}
		return $url;
	}
  
} 
class ControllerExtensionShippingSendbox extends Controller{
    private $error = array();

    public function index(){
      
    $this->load->language('extension/shipping/sendbox');
    $this->document->setTitle($this->language->get('heading_title'));
    $this->load->model('setting/setting');

    if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
        $this->model_setting_setting->editSetting('sendbox', $this->request->post);
   
        $this->session->data['success'] = $this->language->get('text_success');
   
        $this->response->redirect($this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL'));
      } 
      
    $data['heading_title'] = $this->language->get('heading_title');  
    $data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
    $data['entry_status'] = $this->language->get('entry_status');
      //loading the breadcrumbs
     $data['breadcrumbs'][] = array(
        'text' => $this->language->get('text_home'),
        'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        ); 
        
        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('text_shipping'),
          'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=shipping', true)
          );

          $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/shipping/sendbox', 'user_token=' . $this->session->data['user_token'], true)
            ); 

            //get geo zones and status 


            if (isset($this->request->post['custom_geo_zone_id'])) {
              $data['custom_geo_zone_id'] = $this->request->post['custom_geo_zone_id'];
            } else {
              $data['custom_geo_zone_id'] = $this->config->get('custom_geo_zone_id');
            }
            
             
           if (isset($this->request->post['sendbox_status'])) {
           $data['sendbox_status'] = $this->request->post['sendbox_status'];
           } else {
           $data['sendbox_status'] = $this->config->get('sendbox_status');
           }

            
            //get zones status from oc root model 
            $this->load->model('localisation/geo_zone');
            $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones(); 
            
         
     //calling header, leftcolumn and footer 
    $data['header'] = $this->load->controller('common/header');
    $data['column_left'] = $this->load->controller('common/column_left');
    $data['footer'] = $this->load->controller('common/footer');
/*     $shipping_obj = new  Sendbox_Shipping_API();
    $api_url = $shipping_obj->get_sendbox_api_url("countries");
    $apiii = $shipping_obj->get_api_response_by_curl($api_url);
    var_dump($api_url);
    die(); */
    $this->response->setOutput($this->load->view('extension/shipping/sendbox', $data)); 

    }
    
} 

